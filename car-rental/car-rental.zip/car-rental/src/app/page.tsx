"use client";

import React from "react";
import UserLogin from "./components/login";

const App = () => {
  return (
    <div className="app-container">
      <UserLogin />
    </div>
  );
};

export default App;
