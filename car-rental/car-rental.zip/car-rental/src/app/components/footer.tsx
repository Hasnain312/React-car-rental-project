import React from "react";
function Footer(){
    return(
        <footer style={{ backgroundColor: '#FFBF00', color: 'black', textAlign: 'center', padding: '10px 0' }}>
        Developed by Tabinda Barag
      </footer>
      );
};

export default Footer;
